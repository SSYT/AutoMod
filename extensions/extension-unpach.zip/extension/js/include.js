!function() {
	function showUserDialog(string)
	{
		x = $('body').after('<div id="fa_notif">'+ string +'</div>');
		setTimeout(function() {
			$('#fa_notif').remove();
		}, 2000);
		
		return x;
	};

	function rwiteDB(status, file, content)
	{
		if(status == 0)
		{
			$.post('/admin/index.forum?part=modules&sub=html&mode=js_edit&extended_admin=1&tid=' + FA.Panel.tid, {
				"title": "[SSMod Install] " + file.name.split('.js')[0],
				"content": content,
				"mode": "save",
				"submit": 1,
			}).done(function() {
				ShowTextareaLang(file, localStorage.getItem('langshort'));
				localStorage.setItem('tmp_file_name', file.name.split('.js')[0]);
			});
		}
	}
	
	function InstallSteepBySteep(button) {
		var storage = window.localStorage;
		$('fieldset#fa-install '+ button +'').click(function(d) {
			d.preventDefault();
			$('fieldset#fa-install legend').html('Instalare ' + storage['tmp_file_name']);
			$('fieldset#fa-install dl').remove();
			$('fieldset#fa-install legend').after('<p style="text-align: center;color: #369fcf;font-size: 14px;">Instalarea va porni imediat ...</p>');
			$.get('/admin/index.forum?mode=js&part=modules&sub=html&tid=' + location.href.split('tid=')[1]).done(function(data) {
				$('form#pageListHtml table#listJs tbody', data).each(function() {
					var url = $('tr:contains("\[SSMod Install\] '+ localStorage.getItem('tmp_file_name') +'") td.row1.url_ltr > a[href]', this).eq(0).attr('href');
					console.log(url);
					$.getScript(url);
					console.log("aaaa");
				});
			});
			$(this).remove();
		});
	}
	
	function ShowTextareaLang(files, lang)
	{
		switch(lang) {
			case 'ro':
				showUserDialog('Extensia a fost incarcata cu succes !');
				$('div#upload').parent().addClass('fa-config');
				$('div#upload').parent().find('legend').html('Configurare');
				$('div#upload').replaceWith('<dl><dt>Afisare '+ files.name.split('.js')[0] +': </dt><dd><dd><input type="radio" class="radio" name="show_module" id="show_module_yes" value="1" checked="checked"><label for="show_module_yes"> Da</label><input type="radio" class="radio" name="show_module" id="show_module_no" value="0"><label for="show_module_no"> Nu</label></dd></dd></dl><dl><dt>Afisare avatare: </dt><dd><dd><input type="radio" class="radio" name="show_avatars_ext" id="show_av_yes" value="0"><label for="show_av_yes"> Da</label><input type="radio" class="radio" name="show_avatars_ext" id="show_av_no" value="1" checked="checked"><label for="show_av_no"> Nu</label></dd></dd></dl><dl><dt>Cookie: </dt><dd><input type="text" name="time_of_cookie" id="ext_cookie" placeholder="12 hour default" /></dd></dl> <dl><dt>Limba: </dt><dd>'+ localStorage.getItem('language') +'</dd></dl><br /><input type="submit" name="conf_submit" value="Inregistrare" class="icon_ok" />');
				
				InstallSteepBySteep('input[type="submit"]');
				break;
				
			case 'en':
				showUserDialog('The extension was loaded successfully!');
				$('div#upload').parent().addClass('fa-config');
				$('div#upload').parent().find('legend').html('Configuration');
				$('div#upload').replaceWith('<dl><dt>Display '+ files.name.split('.js')[0] +': </dt><dd><dd><input type="radio" class="radio" name="show_module" id="show_module_yes" value="1" checked="checked"><label for="show_module_yes"> Yes</label><input type="radio" class="radio" name="show_module" id="show_module_no" value="0"><label for="show_module_no"> No</label></dd></dd></dl><dl><dt>Show avatars: </dt><dd><dd><input type="radio" class="radio" name="show_avatars_ext" id="show_av_yes" value="0"><label for="show_av_yes"> Yes</label><input type="radio" class="radio" name="show_avatars_ext" id="show_av_no" value="1" checked="checked"><label for="show_av_no"> No</label></dd></dd></dl><dl><dt>Cookie: </dt><dd><input type="text" name="time_of_cookie" id="ext_cookie" placeholder="12 hour default" /></dd></dl> <dl><dt>Limba: </dt><dd>'+ localStorage.getItem('language') +'</dd></dl><br /><input type="submit" name="conf_submit" value="Registration" class="icon_ok" />');
				break;
				
			case 'fr':
				showUserDialog('L\'extension a été chargé avec succès!');
				$('div#upload').parent().addClass('fa-config');
				$('div#upload').parent().find('legend').html('Configuration');
				$('div#upload').replaceWith('<dl><dt>Afficher '+ files.name.split('.js')[0] +': </dt><dd><dd><input type="radio" class="radio" name="show_module" id="show_module_yes" value="1" checked="checked"><label for="show_module_yes"> Oui</label><input type="radio" class="radio" name="show_module" id="show_module_no" value="0"><label for="show_module_no"> Non</label></dd></dd></dl><dl><dt>Afficher les avatars: </dt><dd><dd><input type="radio" class="radio" name="show_avatars_ext" id="show_av_yes" value="0"><label for="show_av_yes"> Oui</label><input type="radio" class="radio" name="show_avatars_ext" id="show_av_no" value="1" checked="checked"><label for="show_av_no"> Pas</label></dd></dd></dl><dl><dt>Cookie: </dt><dd><input type="text" name="time_of_cookie" id="ext_cookie" placeholder="Par défaut 12 heures" /></dd></dl> <dl><dt>Limba: </dt><dd>'+ localStorage.getItem('language') +'</dd></dl><br /><input type="submit" name="conf_submit" value="Inscription" class="icon_ok" />');
				break;
				
			case 'it':
				showUserDialog('L\'estensione è stato caricato con successo!');
				$('div#upload').parent().addClass('fa-config');
				$('div#upload').parent().find('legend').html('Configurazione');
				$('div#upload').replaceWith('<dl><dt>Display '+ files.name.split('.js')[0] +': </dt><dd><dd><input type="radio" class="radio" name="show_module" id="show_module_yes" value="1" checked="checked"><label for="show_module_yes"> Sì</label><input type="radio" class="radio" name="show_module" id="show_module_no" value="0"><label for="show_module_no"> Pas</label></dd></dd></dl><dl><dt>Mostra avatar: </dt><dd><dd><input type="radio" class="radio" name="show_avatars_ext" id="show_av_yes" value="0"><label for="show_av_yes"> Sì</label><input type="radio" class="radio" name="show_avatars_ext" id="show_av_no" value="1" checked="checked"><label for="show_av_no"> Non</label></dd></dd></dl><dl><dt>Cookie: </dt><dd><input type="text" name="time_of_cookie" id="ext_cookie" placeholder="predefinita 12 ore" /></dd></dl> <dl><dt>Limba: </dt><dd>'+ localStorage.getItem('language') +'</dd></dl><br /><input type="submit" name="conf_submit" value="Registrazione" class="icon_ok" />');
				break;
		}
		return true;
	};
	
	if(!window.FA) window.FA = {};
	var table = "", table2 = "", i = 0;
	window.FA.Panel =
	{
		tid: location.href.split('tid=')[1],
		translate:
		{
			ro: {
				'modname': 'Extensii',
				'explain': 'Aici puteti adauga <strong>extensii/module</strong> la forumul dvs, cum ar fi un top 5, un widget personalizat, sau ori care extensie din lista. Pentru cei mai experimentati dintre dvs., puteti crea propriile dvs. module si puteti adauga propriile coduri.',
				'header': 'Extensii &amp; Module'
			},
			
			en: {
				'modname': 'Extensions',
				'explain': 'You can add <strong> extensions / modules </ strong> in your forum, such as a top 5, a custom widget, or any extension of that list. For the most experienced of you, you can create your own modules and can add their own codes.',
				'header' : 'Mode &amp; Extensions'
			},
			
			fr: {
				'modname': 'Extensions',
				'explain': 'Vous pouvez ajouter <strong> extensions / modules </strong> dans votre forum, comme un top 5, un widget personnalisé, ou toute extension de cette liste. Pour les plus expérimentés d\'entre vous, vous pouvez créer vos propres modules et peuvent ajouter leurs propres codes.',
				'header' : 'Extensions &amp; modules'
			}
		},
		
		verify:
		{
			module: function(name)
			{
				$.get('/admin/index.forum?mode=js&part=modules&sub=html&tid=' + FA.Panel.tid, function(d) {
					$('form#pageListHtml table#listJs tbody:eq(0)', d).each(function() {
						var x = $('tr:contains("[SSMod Modules] '+ name +'")', this).length;
						if(x == 1)
						{
							return x;
						}
					});
				});
			}
		},
		
		getAppName: function(id)
		{
			var name = "";
			if(id == 1) 
				name = "Top Five";
			if(id == 2) 
				name = "Newest Member Today";
			if(id == 3) 
				name = "Topic Preview";
			return name;
		},
		
		configExt: function(id) {
			if(id == 1)
			{
				var t = '<dl><dt><label>Afiseaza Top Five&nbsp;:</label></dt> <dd><input type="radio" name="activate_topfive" checked="checked" id="activate_topfive_yes" value="1" class="radio"><label for="activate_topfive_yes"> Da</label><input type="radio" name="activate_topfive" id="activate_topfive_no" value="0" class="radio"><label for="activate_topfive_no"> Nu</label> </dd></dl>';
					t += '<dl><dt><label>Afiseaza avatarele&nbsp;:</label></dt> <dd><input type="radio" name="show_pics" id="show_pics_yes" value="1" class="radio"><label for="show_pics_yes"> Da</label><input type="radio" name="show_pics" id="show_pics_no" checked="checked" value="0" class="radio"><label for="show_pics_no"> Nu</label> </dd></dl>';
					t += '<dl><dt><label>Schimba limba&nbsp;:</label></dt><dd><select name="rate_type" id="rate_type"><option value="0" selected="selected">Default</option><option value="1">Romana</option><option value="2">Engleza</option></select></dd></dl>';
					t += '<div class="div_btns"><input type="submit" name="submitted" value="Inregistrare" class="icon_ok"></div>';
				return t;
			}
		},
		
		checkUpdated:
		{
			modules: function() {
				if(/&sub=modules/g.test(location.href) && !/&mode=ext_view&id=/g.test(location.href))
				{
					$.get('https://raw.githubusercontent.com/SSYT/SSMod/master/extensions/release.js', function(d) {
						$('#main-content').append('<script type="text/javascript">//<![CDATA[\n '+ d +' //]]></script>');
						if(window.Avaible) {
							var tablex = '<table id="listExt" cellspacing="1" cellpadding="4" border="0" align="center" width="85%" class="tablesorter">'+
								'<thead><tr><th id="column_title" class="headerSort headerSortDown">Nume<span class="imgSort">&nbsp;</span></th><th id="column_address" class="headerSort">URL<span class="imgSort">&nbsp;</span></th><th>Actiune</th></tr></thead>'+
								'<tbody>';
								for(i in Avaible)
								{
									if(FA.Panel.verify.module(Avaible[i][0]) == true)
									{
										
									}
									table2 += '<tr align="center" class="row1">'+
											'<td>'+ Avaible[i][0] +'</td>'+
											'<td>'+ Avaible[i][1] +'</td>'+
											'<td><a href="'+ Avaible[i][2] +''+ FA.Panel.tid +'"><i class="fa fa-cog edit"></i></a></td>'+
									'</tr>';
								}
								tablex += ''+ table2 +'</tbody>'+
							'</table>';
							$('#pageListHtml').html(tablex);
						}
					});
				}
				
				if(/&mode=ext_view&id=/g.test(location.href))
				{
					var id = location.href.split('&id=')[1].split('&extended_admin=1')[0];
					$('ul.h2-breadcrumb').append('<li>'+ FA.Panel.getAppName(id) +'</li>');
					if(id == 1)
						$('p.explain').html('<b>Top Five Mod</b> este o extensie creata in scopul de a adauga pe forum un top 5 statistici. Aici puteti configura modulul in buna voie.<br /><br /><b>Atentie</b> editarea acestui modul poate produce erori in sursa codului, va amintim ca nu este destina incepatorilor.');
					else if(id == 1)
						$('p.explain').html('<b>Newest Member Today</b> ');
					else if(id == 1)
						$('p.explain').html('<b>Topic Preview</b> ');
					
					$('form#pageListHtml').parent().find('legend').html('Configurare');
					$('form#pageListHtml').html(FA.Panel.configExt(id));
				}
				
				if(/extensions/g.test(location.href) && !/&sub=modules/g.test(location.href) && !/&mode=ext_view&id=/g.test(location.href))
				{
					$.get('https://raw.githubusercontent.com/SSYT/SSMod/master/extensions/release.js', function(d) {
						$('#main-content').append('<script type="text/javascript">//<![CDATA[\n '+ d +' //]]></script>');
						if(window.ModuleList) {
							for(i in ModuleList)
							{
								var id = parseInt(i) + 1;
								table2 += '<tr align="center" class="row1">'+
										'<td>'+ ModuleList[i][0] +'</td>'+
										'<td>'+ ModuleList[i][1] +'</td>'+
										'<td>'+ ModuleList[i][2] +'</td>'+
										'<td>'+ ModuleList[i][3] +'</td>'+
								'</tr>';
							}
							
							table += '<table cellpadding="0" cellspacing="0" border="0">'+
								'<tbody>'+
									'<tr>'+
										'<td width="100%">'+
											'<fieldset><legend>Extensii &amp; Module</legend>'+
											'<table id="ext_mode">'+
												'<thead><tr><th width="34%">Nume</th><th width="24%">Autor</th><th width="24%">Ultima actualizare</th><th width="24%">Versiune</th></tr></thead>'+
												'<tbody>' + table2 + '</tbody>'+
											'</table>'+
											'</fieldset>'+
										'</td>'+
									'</tr>'+
								'</tbody>'+
							'</table>';
							$('.main_icones').after(table);
						}
					});
				}
			}
		},
		
		getScript: function(url)
		{
			$.getScript(url);
		},
		
		pages: function()
		{
			var lang = "", langshort = "";
			$.get('/admin/index.forum?mode=general&part=general&sub=general&tid='+ location.href.split('tid=')[1] +'').done(function(x) {
				langshort += $('form fieldset:eq(0) dd:eq(3) select[name="default_lang"] option[selected="selected"]', x).val();
				lang += $('form fieldset:eq(0) dd:eq(3) select[name="default_lang"] option[selected="selected"]', x).text();
				localStorage.setItem('language', lang);
				localStorage.setItem('langshort', langshort);
			});
			
			if(/mode=js&part=modules&sub=html&mode=js/g.test(location.href) || /\?mode=js&part=modules&sub=html/g.exec(window.location.href))
			{
				$('table#listJs tbody').each(function() {
					$('tr:contains("\[SSMod Modules\]")').hide().addClass('db-storage');
					$('tr:contains("\[FA Module\]"), tr:contains("\[FA Modules\]")').hide().addClass('db-storage');
					$('tr:contains("\[SSMod Install\]")').hide().addClass('db-storage');
				});
				console.log('Gestiune JS');
			}
			
			if(/extensions/g.test(location.href) && !/&sub=modules/g.test(location.href) && !/&sub=install_modules/g.test(location.href))
			{
				$('a[href^="/admin/index.forum?part=extensions"]').parent().attr('id','activetab');
				$('#main-content').append('<style type="text/css">fieldset {margin-bottom:5px!important;margin-right:5px!important;margin-top:5px!important;margin-left:5px!important;padding: 10px 10px 10px 10px !important;}</style>');
				$('#main-content').append('<h2>'+ FA.Panel.translate.ro["modname"] +'</h2>');
				$('#main-content').append('<blockquote class="block_left"><p class="explain">'+ FA.Panel.translate.ro["explain"] +'</p></blockquote><div class="main_icones clearfix"></div>');
				$('#menu').prepend('<div class="header">&nbsp;'+ FA.Panel.translate.ro["modname"] +'</div>');
				$('#menu .header:eq(0)').after('<div class="coins-top"><div class="left-top">&nbsp;&nbsp;<i class="fa fa-code"></i>&nbsp;'+ FA.Panel.translate.ro["header"] +'</div></div><br clear="all">');
				$('#menu br[clear="all"]').after('<div class="coins-border"><div class="submenu"><a href="/admin/index.forum?part=extensions&sub=install_modules&tid='+ FA.Panel.tid +'"><span>Instalare Extensii</span></a></div> <div class="submenu"><a href="/admin/index.forum?part=extensions&sub=modules&tid='+ FA.Panel.tid +'"><span>Gestionare extensii</span></a></div></div>');
				FA.Panel.checkUpdated.modules();
			}
			
			if(/sub=modules/g.test(location.href) && !/&sub=install_modules/g.test(location.href))
			{
				$('a[href^="/admin/index.forum?part=extensions"]').parent().attr('id','activetab');
				
				$('#menu').prepend('<div class="header">&nbsp;'+ FA.Panel.translate.ro["modname"] +'</div>');
				$('#menu .header:eq(0)').after('<div class="coins-top"><div class="left-top">&nbsp;&nbsp;<i class="fa fa-code"></i>&nbsp;'+ FA.Panel.translate.ro["header"] +'</div></div><br clear="all">');
				$('#menu br[clear="all"]').after('<div class="coins-border"><div class="coins-border"><div class="submenu"><a href="/admin/index.forum?part=extensions&sub=install_modules&tid='+ FA.Panel.tid +'"><span>Instalare Extensii</span></a></div> <div id="activesubmenu"><a href="/admin/index.forum?part=extensions&sub=modules&tid='+ FA.Panel.tid +'"><span>Gestiune extensii</span></a></div></div>');
				$('.coins-border > div:eq(2)').attr('id','activesubmenu');
				
				$('#main-content').append('<style type="text/css">fieldset {margin-bottom:5px!important;margin-right:5px!important;margin-top:5px!important;margin-left:5px!important;padding: 10px 10px 10px 10px !important;}</style>');
				$('#main-content').append('<h2>'+ FA.Panel.translate.ro["modname"] +'</h2> <ul class="h2-breadcrumb clearfix"><li class="first">Gestiune extensii</li></ul>');
				$('.h2-breadcrumb').after('<blockquote class="block_left"><p class="explain">In aceasta sectiune puteti gestiona extensiile pe care doriti sa le adaugati in forumul dumneavoastra.<br /><br /><b>Atentie!</b> Aceasta sectiune este destinata utilizatorilor avansati. Pentru a functiona dupa publicare, codurile nu trebuie sa contina erori. Noi vom asigura optimizarea codurilor pentru o mai buna incarcare a paginilor forumului.</p></blockquote><div class="main_icones clearfix"></div>');
				$('blockquote.block_left').after('<fieldset><legend>'+ FA.Panel.translate.ro["modname"] +'</legend><form id="pageListHtml" method="post" name="tablesForm" action=""></form></fieldset>');
				// FA.Panel.checkUpdated.modules();
			}
			
			if(/&sub=install_modules/g.test(location.href) && !/sub=modules/g.test(location.href))
			{
				$('a[href^="/admin/index.forum?part=extensions"]').parent().attr('id','activetab');
				$('#main-content').append('<style type="text/css">fieldset {margin-bottom:5px!important;margin-right:5px!important;margin-top:5px!important;margin-left:5px!important;padding: 10px 10px 10px 10px !important;}</style>');
				$('#main-content').append('<h2>'+ FA.Panel.translate.ro["modname"] +'</h2> <ul class="h2-breadcrumb clearfix"><li class="first">Instalare extensii</li></ul>');
				$('#main-content').append('<blockquote class="block_left"><p class="explain"><b>Pentru extentii mergeti pe <b><a style="color: #c00;" href="https://ssyt.github.io/FA-Store/" target="_blank">FA Store</a></b> si descarcati de acolo extensia dorita.<br /><br /><b>Atentie</b> Pentru ca modulele sa functioneze trebuie sa nu contina erori, noi ne vom ocupa de coduri sa fie optimizate pentru a nu crea probleme forumului !</b></p></blockquote><div class="main_icones clearfix"></div><fieldset id="fa-install"><legend>Instalare Extensie</legend><div id="upload"></div></fieldset>');
				$('#menu').prepend('<div class="header">&nbsp;'+ FA.Panel.translate.ro["modname"] +'</div>');
				$('#menu .header:eq(0)').after('<div class="coins-top"><div class="left-top">&nbsp;&nbsp;<i class="fa fa-code"></i>&nbsp;'+ FA.Panel.translate.ro["header"] +'</div></div><br clear="all">');
				$('#menu br[clear="all"]').after('<div class="coins-border"><div class="coins-border"><div id="activesubmenu"><a href="/admin/index.forum?part=extensions&sub=install_modules&tid='+ FA.Panel.tid +'"><span>Instalare Extensii</span></a></div> <div class="submenu"><a href="/admin/index.forum?part=extensions&sub=modules&tid='+ FA.Panel.tid +'"><span>Gestiune extensii</span></a></div></div>');
				$('#upload').html('<input type="file" name="file" id="fa_file">');
				
				// Upload And save File
				var content = "", line = 0;
				var file = document.getElementById('fa_file');
				file.onchange = function() {
					var file = this.files[0];
					var reader = new FileReader();
					reader.onload = function(progressEvent) {
						var lines = this.result;
						for(line in lines) {
							content += lines[line];
						}
						
						$.get('/admin/index.forum?mode=js&part=modules&sub=html&tid=' + FA.Panel.tid).done(function(data) {
							var status = -1; 
							
							$('form#pageListHtml table#listJs tbody', data).each(function() {
								var a = $('tr:contains("\[SSMod Install\] Top Five")', this).length;
								status = a;
							});
							console.log(status);
							if(status > 0)
							{
								showUserDialog('Aceasta extensie exista deja in baza de date.');
								setTimeout(function()
								{
									location.reload();
								}, 3000);
							} else {
								rwiteDB(0, file, content);
							}
						});
					};
					reader.readAsText(file);
				};
			}
		}
	};

	$(FA.Panel.pages);
	$("#tabs ul li:last").after('<li><a href="/admin/index.forum?part=extensions&tid='+ FA.Panel.tid +'"><span class="tab">'+ FA.Panel.translate.ro["modname"] +'</span></a></li>');
}();