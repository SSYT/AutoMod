/*
	* Forumotion Extension Plugins
	* https://ssyt.github.io/FA-Store/
	* v1.0.a
*/

(function() {
	// Global Defines
	
	var TID = location.href.split('tid=')[1],
		langCode = 'ro',
		trans, 
		PDO = window.localStorage,
		lang = $('a[href^="/admin/index.forum?part=admin&tid="]').text();
	
	var iconList = [
		'',
		'',
		'',
		'',
		''
	];
	
	var icons = {
		load: iconList[0],
		info: iconList[1],
		error: iconList[2],
		success: iconList[3],
		disable: iconList[4]
	};
	
	function timestamp() {
		return Math.floor((new Date()).getTime() / 1000);
	}
	
	function Logs(str)
	{
		if(window.console && str !== "")
			console.log(str);
	}
	
	function installSSModSettings()
	{
		$.get('/admin/index.forum?mode=js&part=modules&sub=html&tid=' + TID).done(function(response, status, xht) {
			if(xht.status == 200)
			{
				var total = $('form#pageListHtml table#listJs tbody tr:contains("SSMod Config")', response).length;
				if(total == 0)
				{
					$.post('/admin/index.forum?part=modules&sub=html&mode=js_edit&extended_admin=1&tid=' + TID, {
						"title": "SSMod Config",
						"content": "window.SSModSettings = ['on',\n'ro',\n'no'];",
						"js_placement[]": 'allpages',
						"mode": "save",
						"submit": 1
					}).done(function(response, status, xht) {
						if(xht.status == 200)
						{
							if (allowNotification) {
								new Notification("SSMod Config", {
									body: "Configurarile SSMod au fost adaugate si salvate cu succes !",
								});
							}
						}
					});
				}
			}
		});
		return true;
	}
	
	function getScriptExt(type, name)
	{
		if(type === 'get')
		{
			$.get('/admin/index.forum?mode=js&part=modules&sub=html&tid=' + TID).done(function(response, status, xtr) {
				if(xtr.status == 200) {
					var total = $('form#pageListHtml table#listJs tbody tr:contains("\[SSMod Install\] '+ name +'")', response).length;
					if(total == 1)
					{
						url = $('form#pageListHtml table#listJs tbody tr:contains("\[SSMod Install\] '+ name +'") > td.url_ltr > a', response).attr('href');
						$.getScript(url);
					}
				}
				console.log('* Load complete');
			});
		}
	}
	
	function createTableDB(url, fileName, fileContent, placeZone)
	{
		// getScriptExt('get', PDO['tmp_ext_name']);
		$.post(url + TID, {
			"title": "[SSMod Plugin] " + fileName,
			"content": fileContent,
			"js_placement[]": placeZone,
			"mode": "save",
			"submit": 1
		}).done(function(response, status, xht) {
			if(xht.status == 200)
			{
				$('.upload, progress').remove();
				$('form#fileinfo').replaceWith('<form name="fa_install" id="fa_install" method="post">Instalarea sa efectuat cu succes !</form>');
				PDO.removeItem('tmp_ext_name');
				PDO.removeItem('tmp_ext_content');
				PDO.removeItem('tmp_ext_staus');
				setTimeout(function() {
					window.location.href = '/admin/index.forum?part=extensions&sub=modules&tid=' + TID;
				}, 3000);
			}
		});
	}
	
	function checkValidExt()
	{
		var file = document.querySelector('#fa_ext');
		file.onchange = function() {
			var ExtFile = this.files[0], ExtName = this.files[0].name, ExtNameEx = this.files[0].name.split('.j')[0];
			
			if (/\.(js|jsx)$/i.test(ExtName) === false ) {
				alert("Not a valid SSMod extension!");
				file.value = "";
			} else {
				var reader = new FileReader();
				reader.onload = function(progressEvent) {
					PDO['tmp_ext_content'] = this.result;
				};
				reader.readAsText(ExtFile);
				
				PDO['tmp_ext_name'] = ExtNameEx;
				$('.valid').html(ExtNameEx + trans.ex['very']);
				checkInstalledExt(ExtNameEx);
			}
		};
	}
	
	function showUserDialog(string)
	{
		x = $('body').after('<div id="fa_notif">'+ string +'</div>');
		setTimeout(function() {
			$('#fa_notif').remove();
		}, 2000);
		
		return x;
	};
	
	function GetInstalledExt()
	{
		var i = 0;
		if(PDO && PDO['installed_ext'])
		{
			$('#ext_list tbody').append(PDO['installed_ext']);
		} else {
			$.get('/admin/index.forum?mode=js&part=modules&sub=html&tid=' + TID).done(function(response, status, xtr) {
				$('form#pageListHtml table#listJs tbody tr:contains("\[SSMod Plugin\]")', response).each(function() {
					var no = parseInt(i) + 1;
					var name = $('td:eq(0)', this).text();
					$('#ext_list tbody').append('<tr align="center"><td>'+ no +'</td><td>'+ name +'</td><td>Da</td><td><a href="#"><i class="fa fa-cog edit" title="'+ trans.ex['editExt'] +'"></i></a>&nbsp;&nbsp;<a href="#"><i class="fa fa-times delete" title="'+ trans.ex['deleteExt'] +'"></i></a></td></tr>');
					PDO['installed_ext'] = '<tr align="center"><td>'+ no +'</td><td>'+ name +'</td><td>Da</td><td><a href="#"><i class="fa fa-cog edit" title="'+ trans.ex['editExt'] +'"></i></a>&nbsp;&nbsp;<a href="#"><i class="fa fa-times delete" title="'+ trans.ex['deleteExt'] +'"></i></a></td></tr>';
				});
			});
		}
		return true;
	}
	
	function checkInstalledExt(name)
	{
		var extName = name;
		
		$.get('/admin/index.forum?mode=js&part=modules&sub=html&tid=' + TID).done(function(response, status, xtr) {
			if(xtr.status == 200)
			{
				var total = $('form#pageListHtml table#listJs tbody tr:contains("\[SSMod Install\] '+ extName +'")', response).length;
				if(total == 0)
				{
					Logs(name + ' is not installed');
					$('span.valid').html(name + trans.ex['isValid']);
					$('form#fileinfo').append('<input type="submit" id="fa_Upload" value="Upload" />');
					uploadExt();
				} else {
					Logs(name + ' is installed');
					setTimeout(function() {
						$('span.valid').html(name + trans.ex['isAllow']);
					}, 2000);
					setTimeout(function() {
						$('span.valid').html("");
					}, 2000);
				}
				PDO['tmp_ext_staus'] = total;
			}
		});
		return true;
	}
	
	function installForm(method)
	{
		var content = "";
		if(method == 'upload')
		{
			content = '<form method="post" id="fileinfo" name="fileinfo"><span class="valid"></span><label>Select a file:</label><br> <input type="file" id="fa_ext" name="file" required /><br /></form>';
		}
		return content;
	}
	
	function uploadExt()
	{
		$('#fa_Upload').click(function(e) {
			e.preventDefault();
			$('form#fileinfo').hide();
			$('form#fileinfo').after('<span class="upload">'+ PDO['tmp_ext_name'] +' se incarca pe host, te rugam sa astepti...</span><progress></progress>');
			var tmp_f_c = PDO['tmp_ext_content'], result = tmp_f_c.replace(/\"/g, "");
			setTimeout(function() {
				createTableDB('/admin/index.forum?part=modules&sub=html&mode=js_edit&extended_admin=1&tid=', PDO['tmp_ext_name'], result, 'viewforum');
			}, 5000);
		});
	}
	
	function getAvaibleExt()
	{
		$.get('https://raw.githubusercontent.com/SSYT/SSMod/master/extensions/release.js', function(d) {
			$('#main-content').append('<script type="text/javascript">//<![CDATA[\n '+ d +' //]]></script>');
			var tablex, i = 0;
			if(window.ModuleList ) {
				for(i in ModuleList)
				{
					var id = parseInt(i) + 1;
					tablex = '<tbody><tr>'+
							'<td align="center" valign="middle" nowrap="nowrap">'+ id +'</td>'+
							'<td align="center" valign="middle" nowrap="nowrap">'+ ModuleList[i][0] +'</td>'+
							'<td align="center" valign="middle" nowrap="nowrap">'+ ModuleList[i][1] +' ['+ ModuleList[i][3] +']</td>'+
							'<td align="center" valign="middle" nowrap="nowrap"><i class="add fa fa-plus" title="Adauga"></i>&nbsp;&nbsp;&nbsp;&nbsp;<i class="edit fa fa-cog" title="Modifica"></i>&nbsp;&nbsp;&nbsp;&nbsp;<i class="delete fa fa-times" title="Sterge"></i>&nbsp;</td>'+
					'</tr></tbody>';
					
					$('#faExt_list').append(tablex);
				}
			}
		});
	}
	
	function CreateMenu(id)
	{
		if(id == 1)
		{
			$('a[href^="/admin/index.forum?part=extensions"]').parent().attr('id','activetab');
			$('#main-content').append('<style type="text/css">fieldset {margin-bottom:5px!important;margin-right:5px!important;margin-top:5px!important;margin-left:5px!important;padding: 10px 10px 10px 10px !important;}</style>');
			$('#main-content').append('<h2>'+ trans['title'] +'</h2>');
			$('#menu').prepend('<div class="header">&nbsp;'+ trans['title'] +'</div>');
			$('#menu .header:eq(0)').after('<div class="coins-top"><div class="left-top">&nbsp;&nbsp;<i class="fa fa-code"></i>&nbsp;'+ trans['title'] +'</div></div><br clear="all">');
			$('#menu br[clear="all"]').after('<div class="coins-border"><div class="submenu"><a href="/admin/index.forum?part=extensions&sub=install_modules&tid='+ TID +'"><span>'+ trans['install_ext'] +'</span></a></div> <div class="submenu"><a href="/admin/index.forum?part=extensions&sub=modules&tid='+ TID +'"><span>'+ trans['manage_ext'] +'</span></a></div></div>');
		}
	}
	
	var translate = {
		ro: {
			title: 			'Extensii &amp; Module',
			install_ext: 	'Instalare Extensii',
			manage_ext: 	'Gestionare extensii',
			notifbody: 		'SSMod Extensii si Module a fost initializat !',
			notificon: 		'',
			notifname: 		'SSMod Extensii',
			
			ex: {
				installPage: 		'Instaleaza o extensie',
				managePage: 		'Gestioneaza Extensii',
				manageExtPage: 		'Extensii Instalate',
				configExtPage:		'Optiuni',
				explainInstall: 	'In aceasta sectiune puteti gestiona <b>extensiile</b> pe care doriti sa le adaugati in forumul dumneavoastra.<br />Pentru a descarca extensii trebuie sa mergeti pe <a href="https://ssyt.github.io/FA-Store/" target="_blank">FA Store</a><br /><br /><b>Atentie!</b> Toate extensiile care sunt instalate trebuie sa fii legale, fara erori !',
				explainManage: 		'',
				explaintHome: 		'In aceasta sectiune puteti gestiona <b>extensiile</b> pe care doriti sa le adaugati in forumul dumneavoastra.<br /><br /><b>Atentie!</b> Aceasta sectiune este destinata utilizatorilor avansati. Pentru a functiona dupa publicare, codurile nu trebuie sa contina erori. Noi vom asigura optimizarea codurilor pentru o mai buna incarcare a paginilor forumului.',
				lista: 				'Lista de extensii disponibile',
				nameExt:			'Numele extensiei',
				authExt:			'Autor/Versiune',
				actionExt: 			'Actiune',
				footerLinks:		'Activati link-urile din subsolul paginilor: ',
				lang:				'Schimba limba',
				statusExt:			'Activeaza Extensii',
				addExt:				'Adauga',
				editExt:			'Modifica',
				deleteExt:			'Sterge ',
				legendTitle:		'Legenda',
				submit: 			'Inregistrare',
				on:					'Da',
				very: 				' este un modul valid, asteptati sa se verifice...',
				isAllow:			' acest modul este deja incarcat sau instalat.<br />Selectati alt modul care doriti sa il instalati',
				isValid:			' este valid pentru instalare.',
				off:				'Nu'
			},
			
			install: {
				title: 			'Instaleaza o extensie',
				btn: 			'Incarca',
				message: 		'',
				uComplete: 		'Extensia a fost incarcata cu succes',
				uError: 		'Extentia nu a putut fii incarcata',
				iMessage: 		'Aceasta extensie a fost instalata cu succes, puteti verifica in ' + this.manage_ext,
				iError: 		'A aparut o eroare la instalare, contactatine la email ssmod@forumcodes.com',
				iSucces: 		'Extensia a fost adaugata cu succes pe forum',
				isExist:		'Se pare ca modulul selectat a fost deja instalat..',
				noExtSelect:	'Trebuie sa selectezi un modul valid pentru a fii incarcat...'
			}
		},
		
		en: {
			title: 			'Extensions &amp; Modules',
			install_ext: 	'Instalare Extensii',
			manage_ext: 	'Gestionare extensii',
			configExtPage:	'Optiuni',
			manageExtPage: 	'Extensii Instalate',
			notifbody: 		'Extensions and Modules SSMod was initialized!',
			notificon: 		'',
			notifname: 		'SSMod Extensions',
			
			ex: {
				installPage: 		'Instaleaza o extensie',
				managePage: 		'Gestioneaza Extensii',
				explainInstall: 	'',
				explainManage: 		'',
				explaintHome: 		'In aceasta sectiune puteti gestiona <b>extensiile</b> pe care doriti sa le adaugati in forumul dumneavoastra.<br /><br />Atentie! Aceasta sectiune este destinata utilizatorilor avansati. Pentru a functiona dupa publicare, codurile nu trebuie sa contina erori. Noi vom asigura optimizarea codurilor pentru o mai buna incarcare a paginilor forumului.',
				lista: 				'Lista de extensii disponibile',
				nameExt:			'Numele extensiei',
				authExt:			'Autor/Versiune',
				actionExt: 			'Actiune',
				footerLinks:		'Activati link-urile din subsolul paginilor: ',
				lang:				'Schimba limba',
				statusExt:			'Activeaza Extensii',
				addExt:				'Adauga',
				editExt:			'Modifica',
				deleteExt:			'Sterge ',
				legendTitle:		'Legenda',
				submit: 			'Inregistrare',
				on:					'Da',
				very: 				' is a valid SSMod Module, wait to verify...',
				isAllow:			' module is already installed.',
				isValid:			' module is avaible to install.',
				off:				'Nu'
			},
			
			install: {
				title: 			'Instaleaza o extensie',
				btn: 			'Incarca',
				message: 		'',
				uComplete: 		'Extensia a fost incarcata cu succes',
				uError: 		'Extentia nu a putut fii incarcata',
				iMessage: 		'Aceasta extensie a fost instalata cu succes, puteti verifica in ' + this.manage_ext,
				iError: 		'A aparut o eroare la instalare, contactatine la email ssmod@forumcodes.com',
				iSucces: 		'Extensia a fost adaugata cu succes pe forum',
				isExist:		'Se pare ca modulul selectat a fost deja instalat..',
				noExtSelect:	'Trebuie sa selectezi un modul valid pentru a fii incarcat...'
			}
		},
		
		it: {
			title: 			'Estensioni e moduli',
			install_ext: 	'Instalare Extensii',
			manage_ext: 	'Gestionare extensii',
			configExtPage:	'Optiuni',
			manageExtPage: 	'Extensii Instalate',
			notifbody: 		'Estensioni e moduli SSMod è stato inizializzato!',
			notificon: 		'',
			notifname: 		'Estensioni e moduli',
			
			ex: {
				installPage: 		'Instaleaza o extensie',
				managePage: 		'Gestioneaza Extensii',
				explainInstall: 	'',
				explainManage: 		'',
				explaintHome: 		'In aceasta sectiune puteti gestiona <b>extensiile</b> pe care doriti sa le adaugati in forumul dumneavoastra.<br /><br />Atentie! Aceasta sectiune este destinata utilizatorilor avansati. Pentru a functiona dupa publicare, codurile nu trebuie sa contina erori. Noi vom asigura optimizarea codurilor pentru o mai buna incarcare a paginilor forumului.',
				lista: 				'Lista de extensii disponibile',
				nameExt:			'Numele extensiei',
				authExt:			'Autor/Versiune',
				actionExt: 			'Actiune',
				footerLinks:		'Activati link-urile din subsolul paginilor: ',
				lang:				'Schimba limba',
				statusExt:			'Activeaza Extensii',
				addExt:				'Adauga',
				editExt:			'Modifica',
				deleteExt:			'Sterge ',
				legendTitle:		'Legenda',
				submit: 			'Inregistrare',
				on:					'Da',
				very: 				' is a valid SSMod Module, wait to verify...',
				isAllow:			'',
				isValid:			' module is avaible to install.',
				off:				'Nu'
			},
			
			install: {
				title: 			'Instaleaza o extensie',
				btn: 			'Incarca',
				message: 		'',
				uComplete: 		'Extensia a fost incarcata cu succes',
				uError: 		'Extentia nu a putut fii incarcata',
				iMessage: 		'Aceasta extensie a fost instalata cu succes, puteti verifica in ' + this.manage_ext,
				iError: 		'A aparut o eroare la instalare, contactatine la email ssmod@forumcodes.com',
				iSucces: 		'Extensia a fost adaugata cu succes pe forum',
				isExist:		'Se pare ca modulul selectat a fost deja instalat..',
				noExtSelect:	'Trebuie sa selectezi un modul valid pentru a fii incarcat...'
			}
		}
	};
	
	if(lang === 'Pagina de start')
		langCode = "ro";
	
	if(lang === 'Home')
		langCode = "en";
	
	if(lang === 'Indice')
		langCode = "it";
	
	trans = translate[langCode];
	
	// Browser Notifications
	var allowNotification = true;
	Notification.requestPermission(function (result) {
		if (result === "denied") {
			allowNotification = false;
			return;
		} else if (result === "default") {
			allowNotification = false;
			return;
		}
		allowNotification = true;
	});
	
	if (Notification.permission !== "denied") {
		Notification.requestPermission();
	}
	
	if (allowNotification) {
		if(!PDO['notifications'])
		{
			new Notification(""+ trans['notifname'] +"", {
				body: ""+ trans['notifbody'] +"",
			});
			PDO['notifications'] = 1;
		}
	}
	
	$("#tabs ul li:last").after('<li><a href="/admin/index.forum?part=extensions&tid='+ TID +'"><span class="tab">'+ trans['title'] +'</span></a></li>');
	
	// Delete all saved temp cache
	PDO.removeItem('tmp_ext_content');
	PDO.removeItem('tmp_file_content');
	PDO.removeItem('tmp_ext_name');
	PDO.removeItem('tmp_ext_steep');
	PDO.removeItem('tmp_ext_staus');
	
	Logs("* All temp content reload");
	Logs("* SSMod Auto Installer initialize...");
	installSSModSettings();
	
	// Show content with page stat
	if(/extensions/g.test(location.href) && !/&sub=modules/g.test(location.href) && !/&sub=install_modules/g.test(location.href))
	{
		CreateMenu(1);
		getAvaibleExt();
		$('#main-content').append('<blockquote class="block_left"><p class="explain">'+ trans.ex['explaintHome'] +'</p></blockquote><div class="main_icones clearfix"></div>');
		if(PDO && PDO['temp_ext_avaible'])
			$('#main-content').append('<fieldset><legend>'+ trans.ex['lista'] +'</legend><table id="faExt_list" cellspacing="1" summary="'+ trans.ex['lista'] +'"><thead><tr><th valign="middle" nowrap="nowrap">#</th><th valign="middle" nowrap="nowrap">'+ trans.ex['nameExt'] +'</th><th valign="middle" nowrap="nowrap">'+ trans.ex['authExt'] +'</th><th valign="middle" nowrap="nowrap">'+ trans.ex['actionExt'] +'</th></tr></thead>'+ PDO['temp_ext_avaible'] +'</table></fieldset>');
		else 
			$('#main-content').append('<fieldset><legend>'+ trans.ex['lista'] +'</legend><table id="faExt_list" cellspacing="1" summary="'+ trans.ex['lista'] +'"><thead><tr><th valign="middle" nowrap="nowrap">#</th><th valign="middle" nowrap="nowrap">'+ trans.ex['nameExt'] +'</th><th valign="middle" nowrap="nowrap">'+ trans.ex['authExt'] +'</th><th valign="middle" nowrap="nowrap">'+ trans.ex['actionExt'] +'</th></tr></thead></table></fieldset>');
	}
	
	if(/mode=js&part=modules&sub=html&mode=js/g.test(location.href) || /part=modules&sub=html&mode=js&extended_admin=1/g.test(location.href) || /\?mode=js&part=modules&sub=html/g.exec(window.location.href))
	{
		$('table#listJs tbody').each(function() {
			$('tr:contains("\[SSMod Modules\]"), tr:contains("SSMod Config")').hide().addClass('db-storage');
			$('tr:contains("\[FA Module\]"), tr:contains("\[SSMod Plugin\]"), tr:contains("\[FA Modules\]")').hide().addClass('db-storage');
			$('tr:contains("\[SSMod Install\]")').hide().addClass('db-storage');
		});
		console.log('Gestiune JS');
	}
	
	// Pagina de gestiune extensii
	if(/sub=modules/g.test(location.href) && !/&sub=install_modules/g.test(location.href))
	{
		$('a[href^="/admin/index.forum?part=extensions"]').parent().attr('id','activetab');
		$('#main-content').append('<style type="text/css">fieldset {margin-bottom:5px!important;margin-right:5px!important;margin-top:5px!important;margin-left:5px!important;padding: 10px 10px 10px 10px !important;}</style>');
		$('#main-content').append('<h2>'+ trans['title'] +'</h2>');
		$('#menu').prepend('<div class="header">&nbsp;'+ trans['title'] +'</div>');
		$('#menu .header:eq(0)').after('<div class="coins-top"><div class="left-top">&nbsp;&nbsp;<i class="fa fa-code"></i>&nbsp;'+ trans['title'] +'</div></div><br clear="all">');
		$('#menu br[clear="all"]').after('<div class="coins-border"><div class="submenu"><a href="/admin/index.forum?part=extensions&sub=install_modules&tid='+ TID +'"><span>'+ trans['install_ext'] +'</span></a></div> <div id="activesubmenu"><a href="/admin/index.forum?part=extensions&sub=modules&tid='+ TID +'"><span>'+ trans['manage_ext'] +'</span></a></div></div>');
		$('#main-content').append('<blockquote class="block_left"><p class="explain">'+ trans.ex['explainManage'] +'</p></blockquote><div class="main_icones clearfix"></div>');
		$('h2').after('<ul class="h2-breadcrumb clearfix"><li class="first">'+ trans.ex['managePage'] +'</li></ul>');
		$('#main-content').append('<fieldset><legend>'+ trans.ex['configExtPage'] +'</legend><form id="config_ext" method="post" name="ext_manage"><dl><dt>'+ trans.ex['statusExt'] +': </dt><dd><input type="radio" name="ssmod_ext_activate" id="ssmod_ext_activate_yes" checked="checked" value="1" class="radio"><label for="ssmod_ext_activate_yes"> '+ trans.ex['on'] +'</label><input type="radio" name="ssmod_ext_activate" id="ssmod_ext_activate_no" value="0" class="radio"><label for="ssmod_ext_activate_no"> '+ trans.ex['off'] +'</label> </dd></dl> <dl><dt>'+ trans.ex['lang'] +': </dt><dd><select name="ext_lang" id="ext_lang"><option value="ro" selected="selected" title="Romana">Romana</option><option value="en" title="English">English</option><option value="it" title="Italiano">Italiano</option></select></dd></dl> <dl><dt><i class="fa fa-info-circle" data-original-title="" onmouseover="show_tooltip(this,\'Momentan aceasta optiune nu este valabila, cand va fii disponibila va fii anuntat\',\'Tips\');" align="absmiddle" title=""> </i> '+ trans.ex['footerLinks'] +'</dt><dd><input type="radio" name="footer_links_activate" id="footer_links_activate_yes" value="1" class="radio"><label for="footer_links_activate_yes"> '+ trans.ex['on'] +'</label><input type="radio" name="footer_links_activate" id="footer_links_activate_no" value="0" checked="checked" class="radio"><label for="footer_links_activate_no"> '+ trans.ex['off'] +'</label></dd></dl><div class="DIV_BTNS"><input type="submit" value="'+ trans.ex['submit'] +'" class="icon_ok" name="submit"></div></form></fieldset><br /><fieldset class="fieldset_left html-editor"><legend>'+ trans.ex['legendTitle'] +'</legend><i class="fa fa-cog edit" title="'+ trans.ex['editExt'] +'"></i> '+ trans.ex['editExt'] +'&nbsp;&nbsp;&nbsp;<i class="fa fa-times delete" title="'+ trans.ex['deleteExt'] +'"></i> '+ trans.ex['deleteExt'] +'&nbsp;&nbsp;&nbsp;<i class="fa fa-plus add" title="'+ trans.ex['addExt'] +'"></i> '+ trans.ex['addExt'] +'</fieldset><br /><fieldset><legend>'+ trans.ex['manageExtPage'] +'</legend><table cellspacing="1" id="ext_list"></table></fieldset>');
		document.getElementById('ext_list').innerHTML = '<thead><tr><th colspan="4">Extensii instalate pe forum</th></tr></thead>'+
			'<tr class="row3" style="text-align:center;"><td width="10%"><strong>N°</strong></td><td width="60%"><strong>Nume</strong></td><td width="15%"><strong>Activ</strong></td><td width="15%"><strong>Actiune</strong></td></tr>';
		$('.DIV_BTNS input').click(function(e) {
			e.preventDefault();
			alert("Momentan indisponibila aceasta optiune !");
		});	
		GetInstalledExt();
	}
	
	// Pagina de instalare extensii
	if(/&sub=install_modules/g.test(location.href) && !/sub=modules/g.test(location.href))
	{
		$('a[href^="/admin/index.forum?part=extensions"]').parent().attr('id','activetab');
		$('#main-content').append('<style type="text/css">fieldset {margin-bottom:5px!important;margin-right:5px!important;margin-top:5px!important;margin-left:5px!important;padding: 10px 10px 10px 10px !important;}</style>');
		$('#main-content').append('<h2>'+ trans['title'] +'</h2>');
		$('#menu').prepend('<div class="header">&nbsp;'+ trans['title'] +'</div>');
		$('#menu .header:eq(0)').after('<div class="coins-top"><div class="left-top">&nbsp;&nbsp;<i class="fa fa-code"></i>&nbsp;'+ trans['title'] +'</div></div><br clear="all">');
		$('#menu br[clear="all"]').after('<div class="coins-border"><div id="activesubmenu"><a href="/admin/index.forum?part=extensions&sub=install_modules&tid='+ TID +'"><span>'+ trans['install_ext'] +'</span></a></div> <div class="submenu"><a href="/admin/index.forum?part=extensions&sub=modules&tid='+ TID +'"><span>'+ trans['manage_ext'] +'</span></a></div></div>');
		$('#main-content').append('<blockquote class="block_left"><p class="explain">'+ trans.ex['explainInstall'] +'</p></blockquote><div class="main_icones clearfix"></div>');
		$('h2').after('<ul class="h2-breadcrumb clearfix"><li class="first">'+ trans.ex['installPage'] +'</li></ul>');
		$('#main-content').append('<fieldset><legend>'+ trans.install['title'] +'</legend><table id="faExt_list" cellspacing="1" summary="'+ trans.install['title'] +'"><tbody><tr><td>'+ installForm('upload') +'</td></tr></tbody></table></fieldset>');
		checkValidExt();
	}
})();